import React, { useState, useEffect } from "react";
import { fetchDailyData } from "../../api";
import { Line, Bar } from "react-chartjs-2";
import styles from "./Chart.module.css";

const Chart = ({data:{confirmed,recovered,deaths},country}) => {
  const [dailyData, setDailyData] = useState([]);
  useEffect(() => {
    const fetchAPI = async () => {
      setDailyData(await fetchDailyData());
    }
    
    
    fetchAPI();
  },[]);
  const lineChart =
  (
    dailyData.length)

  ? (
    <Line
      data={{ 
        labels: dailyData.map(({date}) => date),
        datasets: [{
data: dailyData.map(({confirmed}) => confirmed),
label: 'infected',
borderColor:'#3333ff',
fill: true,
        }, {
          data: dailyData.map(({deaths}) => deaths),
          label: 'deaths',
          borderColor:'red',
          backgroundcolor: 'rgba(255,0,0,0.5)',
          fill: true,
        }],
      }}
    />
  ) : null;
  
const barChart = (

confirmed
?(
  <Bar 
  data = {{
labels: ['Infected','Recovered','Deaths'],
datasets: [{
label: 'People',
backgroundColor: [
'rgba(9, 9, 233, 0.938)',
'rgba(29, 146, 5, 0.966)', 
'rgba(202, 11, 11, 0.904)'
],
data:[confirmed.value,recovered.value,deaths.value]
}]
  }}
options={{  
  legend: {display:false},
  title: {display:true, text:`Covid-19 statistics in ${country}`,}
}}
  />
) :null
); 
  return (
<div className={ styles.container}>  
  {country ? barChart : lineChart}
</div>
  )
  }
export default Chart;
